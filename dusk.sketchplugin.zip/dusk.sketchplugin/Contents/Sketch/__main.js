var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/main.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(r, a) {
  (null == a || a > r.length) && (a = r.length);
  for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
  return n;
}
module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _arrayWithoutHoles(r) {
  if (Array.isArray(r)) return arrayLikeToArray(r);
}
module.exports = _arrayWithoutHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(r) {
  if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
module.exports = _iterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
module.exports = _nonIterableSpread, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles.js */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");
var iterableToArray = __webpack_require__(/*! ./iterableToArray.js */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");
var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray.js */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");
var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread.js */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");
function _toConsumableArray(r) {
  return arrayWithoutHoles(r) || iterableToArray(r) || unsupportedIterableToArray(r) || nonIterableSpread();
}
module.exports = _toConsumableArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray.js */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");
function _unsupportedIterableToArray(r, a) {
  if (r) {
    if ("string" == typeof r) return arrayLikeToArray(r, a);
    var t = {}.toString.call(r).slice(8, -1);
    return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? arrayLikeToArray(r, a) : void 0;
  }
}
module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./src/main.js":
/*!*********************!*\
  !*** ./src/main.js ***!
  \*********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return onRun; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_1__);

function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }

var UI = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.UI;
function onRun() {
  var doc = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();
  if (!doc) {
    UI.message("⚠️ Please open a document first.");
    return;
  }
  var selection = doc.selectedLayers;
  if (selection.isEmpty) {
    UI.message("⚠️ Please select at least one layer.");
    return;
  }
  var libraries = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.Library.getLibraries().filter(function (l) {
    return l.enabled && l.valid;
  });
  var sourceOptions = ["This Document"].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(libraries.map(function (l) {
    return l.name;
  })));
  var dirOptions = ["Light → Dark", "Dark → Light"];

  // Custom single NSAlert modal
  var alert = NSAlert.alloc().init();
  alert.setMessageText("🎨 Theme Switcher");
  alert.setInformativeText("Select your theme source and direction.");
  try {
    var iconPath = __command.pluginBundle().urlForResourceNamed("icon.png").path();
    var icon = NSImage.alloc().initByReferencingFile(iconPath);
    alert.setIcon(icon);
  } catch (e) {
    console.log("Could not load icon:", e);
  }
  alert.addButtonWithTitle("Switch Theme");
  alert.addButtonWithTitle("Cancel");
  var viewWidth = 300;
  var viewHeight = 110;
  var view = NSView.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, viewHeight));
  var sourceLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, 85, viewWidth, 20));
  sourceLabel.setStringValue("Source Library:");
  sourceLabel.setBezeled(false);
  sourceLabel.setDrawsBackground(false);
  sourceLabel.setEditable(false);
  sourceLabel.setSelectable(false);
  view.addSubview(sourceLabel);
  var sourceDropdown = NSPopUpButton.alloc().initWithFrame(NSMakeRect(0, 60, viewWidth, 25));
  sourceDropdown.addItemsWithTitles(sourceOptions);
  view.addSubview(sourceDropdown);
  var dirLabel = NSTextField.alloc().initWithFrame(NSMakeRect(0, 25, viewWidth, 20));
  dirLabel.setStringValue("Theme Direction:");
  dirLabel.setBezeled(false);
  dirLabel.setDrawsBackground(false);
  dirLabel.setEditable(false);
  dirLabel.setSelectable(false);
  view.addSubview(dirLabel);
  var dirDropdown = NSPopUpButton.alloc().initWithFrame(NSMakeRect(0, 0, viewWidth, 25));
  dirDropdown.addItemsWithTitles(dirOptions);
  view.addSubview(dirDropdown);
  alert.setAccessoryView(view);
  var response = alert.runModal();

  // 1000 is the first button ("Switch Theme")
  if (response === 1000) {
    var sourceSelection = String(sourceDropdown.titleOfSelectedItem());
    var directionSelection = String(dirDropdown.titleOfSelectedItem());
    runThemeSwitch(doc, selection.layers, sourceSelection, directionSelection, libraries);
  }
}
function runThemeSwitch(doc, layers, sourceSelection, directionSelection, libraries) {
  var swatches = [];

  // SWATCH LOADING
  try {
    if (sourceSelection === "This Document") {
      swatches = doc.swatches;
    } else {
      var lib = libraries.find(function (l) {
        return l.name === sourceSelection;
      });
      if (!lib) {
        UI.message("⚠️ Selected library not found.");
        return;
      }
      // Load importable references
      var swatchRefs = lib.getImportableSwatchReferencesForDocument(doc);
      // Must import to use in this document
      swatches = swatchRefs.map(function (ref) {
        return ref.import();
      });
    }
  } catch (err) {
    UI.message("\u26A0\uFE0F Error loading swatches: ".concat(err.message));
    console.error(err);
    return;
  }
  if (!swatches || swatches.length === 0) {
    UI.message("⚠️ No swatches found in the selected source.");
    return;
  }
  var nativeDocData = doc.sketchObject.documentData();
  var pairsMap = new Map(); // baseKey -> { light: Swatch, dark: Swatch }

  // PAIRING LOGIC
  // Parse swatch names into: [Path] / [Light|Dark] / [Variant]
  swatches.forEach(function (swatch) {
    var parts = swatch.name.split("/").map(function (p) {
      return p.trim();
    });
    var theme = null;
    var basePathParts = [];
    var _iterator = _createForOfIteratorHelper(parts),
      _step;
    try {
      for (_iterator.s(); !(_step = _iterator.n()).done;) {
        var part = _step.value;
        var lower = part.toLowerCase();
        if (lower === "light" || lower === "dark") {
          theme = lower; // Extracted theme
        } else {
          basePathParts.push(part);
        }
      }
    } catch (err) {
      _iterator.e(err);
    } finally {
      _iterator.f();
    }
    if (theme) {
      var baseKey = basePathParts.join(" / ");
      if (!pairsMap.has(baseKey)) {
        pairsMap.set(baseKey, {
          light: null,
          dark: null
        });
      }
      pairsMap.get(baseKey)[theme] = swatch;
    }
  });

  // We build the immediate swatchMap and hexMap for known targets
  var swatchMap = new Map();
  var hexFallbackMap = new Map();
  var targetSwatchIDs = new Set();
  var targetHexes = new Set();
  var toDark = directionSelection === "Light → Dark";
  var targetTheme = toDark ? "dark" : "light";
  var sourceTheme = toDark ? "light" : "dark";
  pairsMap.forEach(function (pair, baseKey) {
    if (pair.light && pair.dark) {
      var sourceSwatch = pair[sourceTheme];
      var targetSwatch = pair[targetTheme];

      // Build direct mappings
      swatchMap.set(sourceSwatch.id, targetSwatch);

      // Track targets to prevent double-swaps on already converted elements
      targetSwatchIDs.add(targetSwatch.id);
      if (sourceSwatch.color) {
        // cache hex fallback
        hexFallbackMap.set(normalizeHex(sourceSwatch.color), targetSwatch);
      }
      if (targetSwatch.color) {
        targetHexes.add(normalizeHex(targetSwatch.color));
      }
    }
  });
  function normalizeHex(hex) {
    if (!hex) return "";
    hex = String(hex).toLowerCase().trim();
    if (hex.startsWith("#")) hex = hex.substring(1);
    if (hex.length === 6) hex = hex + "ff";
    return "#" + hex;
  }

  // Resolves what contextually mapping should be applied
  function getTargetSwatch(swatchID, hexValue) {
    if (swatchID) {
      if (swatchMap.has(swatchID)) {
        return swatchMap.get(swatchID);
      }
      // If the swatch resolves to one already matching the desired theme, skip it!
      if (targetSwatchIDs.has(swatchID)) {
        return null;
      }

      // Late resolve: if the swatch isn't in our loaded array (e.g. from foreign doc),
      // identify its name natively and match its base path manually from our loaded targets.
      if (nativeDocData.swatchWithID) {
        var nativeSwatch = nativeDocData.swatchWithID(swatchID);
        if (nativeSwatch) {
          var name = String(nativeSwatch.name());
          var parts = name.split("/").map(function (p) {
            return p.trim();
          });
          var theme = null;
          var basePathParts = [];
          var _iterator2 = _createForOfIteratorHelper(parts),
            _step2;
          try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
              var part = _step2.value;
              var lower = part.toLowerCase();
              if (lower === "light" || lower === "dark") {
                theme = lower;
              } else {
                basePathParts.push(part);
              }
            }
          } catch (err) {
            _iterator2.e(err);
          } finally {
            _iterator2.f();
          }
          if (theme === targetTheme) {
            return null; // The unmatched swatch is ALREADY the selected theme!
          }
          if (theme === sourceTheme) {
            var baseKey = basePathParts.join(" / ");
            if (pairsMap.has(baseKey)) {
              var targetSwatch = pairsMap.get(baseKey)[targetTheme];
              if (targetSwatch) {
                swatchMap.set(swatchID, targetSwatch); // Save for future lookups
                return targetSwatch;
              }
            }
          }
        }
      }
    }

    // FALLBACK: If missing swatch reference entirely, infer destination from hex equivalent
    if (hexValue) {
      var normHex = normalizeHex(hexValue);
      // If the node already explicitly matches the target theme hex, leave it alone.
      if (targetHexes.has(normHex)) {
        return null;
      }
      if (hexFallbackMap.has(normHex)) {
        return hexFallbackMap.get(normHex);
      }
    }
    return null;
  }
  var updateCount = 0;

  // SWITCHING LOGIC & TRAVERSAL
  function processLayer(layer) {
    // Handle normal layer styles (Fills, Borders, Shadows, etc.)
    if (layer.style) {
      var style = layer.style;
      ["fills", "borders", "shadows", "innerShadows"].forEach(function (prop) {
        if (!style[prop]) return;
        style[prop].forEach(function (item) {
          var swatchID = null;
          if (item.sketchObject && typeof item.sketchObject.color === "function") {
            var colorNative = item.sketchObject.color();
            if (colorNative && typeof colorNative.swatchID === "function" && colorNative.swatchID()) {
              swatchID = String(colorNative.swatchID());
            }
          }
          var targetSwatch = getTargetSwatch(swatchID, item.color);
          if (targetSwatch) {
            // ALWAYS assign using swatch.referencingColor
            item.color = targetSwatch.referencingColor;
            updateCount++;
          }

          // Gradient stops
          if (item.gradient && item.gradient.stops) {
            item.gradient.stops.forEach(function (stop) {
              var sID = null;
              if (stop.sketchObject && typeof stop.sketchObject.color === "function") {
                var cNative = stop.sketchObject.color();
                if (cNative && typeof cNative.swatchID === "function" && cNative.swatchID()) {
                  sID = String(cNative.swatchID());
                }
              }
              var sTarget = getTargetSwatch(sID, stop.color);
              if (sTarget) {
                stop.color = sTarget.referencingColor;
                updateCount++;
              }
            });
          }
        });
      });

      // Text Color specifically
      if (layer.type === "Text" && style.textColor) {
        var swatchID = null;
        var nativeStyle = layer.sketchObject.style();
        if (nativeStyle && typeof nativeStyle.textStyle === "function" && nativeStyle.textStyle()) {
          var attrs = nativeStyle.textStyle().attributes();
          if (attrs && attrs.MSAttributedStringColorAttribute) {
            var msColor = attrs.MSAttributedStringColorAttribute;
            if (typeof msColor.swatchID === "function" && msColor.swatchID()) {
              swatchID = String(msColor.swatchID());
            }
          }
        }
        var targetSwatch = getTargetSwatch(swatchID, style.textColor);
        if (targetSwatch) {
          style.textColor = targetSwatch.referencingColor;
          updateCount++;
        }
      }
    }

    // SYMBOL INSTANCES (CRITICAL)
    if (layer.type === "SymbolInstance") {
      layer.overrides.forEach(function (override) {
        // FIX: Use the new .colorOverride boolean to catch all color-related overrides (fills, text, borders, etc.)
        if (override.colorOverride) {
          // If the override hasn't been changed by the user, it relies on the default swatch.
          // Otherwise, it uses the overridden swatch.
          var activeSwatch = override.isDefault ? override.defaultSwatchValue : override.swatchValue;
          var currentSwatchID = null;

          // Check if there is an active swatch attached
          if (activeSwatch && activeSwatch.type === "Swatch") {
            currentSwatchID = activeSwatch.id;
          } else if (!override.isDefault && typeof override.value === "string" && nativeDocData.swatchWithID(override.value)) {
            // Sometimes custom swatches expose just the ID string dynamically in the value property
            currentSwatchID = override.value;
          }

          // Resolves inherited swatch strictly bypassing hex match collisions!
          if (currentSwatchID) {
            var _targetSwatch = getTargetSwatch(currentSwatchID, null);
            if (_targetSwatch) {
              try {
                override.value = _targetSwatch.referencingColor;
              } catch (e) {
                override.value = _targetSwatch.id;
              }
              updateCount++;
            }
          }
        }
      });
    }

    // Recursively traverse all children
    if (layer.layers && layer.layers.length > 0) {
      layer.layers.forEach(processLayer);
    }
  }
  layers.forEach(processLayer);
  var suffix = updateCount === 1 ? "" : "s";
  UI.message("\uD83C\uDFA8 Theme switched \u2014 ".concat(updateCount, " update").concat(suffix));
}

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=__main.js.map